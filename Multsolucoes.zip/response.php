<script>
    {
    "transaction_code": "5EE77A361F714273B25AE9F52CDAA6F1",
    "status": {
        "id": 1,
        "description": "Aguardando pagamento"
    }
}
</script>
<?php
    
    
?>