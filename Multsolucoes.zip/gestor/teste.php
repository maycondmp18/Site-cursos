<?php 
    $text_print = 'DialHost - Desenvolvendo um exemplo com count_chars';
    $str_md1 = count_chars($text_print,1);
    echo '<h2> String de exemplo: '.$text_print.'</h2>';
    echo '<hr>';
    echo '<a name="mod1"><h2> Imprimindo todas as ocorrencias dos caracteres que existem na String:</h2></a>';
    echo '<p>'; 
    foreach ($str_md1 as $key=>$value){echo utf8_encode(chr($key)). ': ' . $value . ' vezes'.'<br>'; };
    echo '</p>';
?>